CMExplorer 1.2
Championship Manager 00/01 database processor.
Copyright 2000/2001 Yuri Kitashin Jr. All rights reserved.

This program is a freeware, so feel free to use redistribute it at will, as long as you do not
charge money for it or use for any other commercial purpose.

New in this release:
- fixed player-on-loan transfer bug;
- fixed club editing bug;
- fixed a couple of minor problems;
- added injury removing capability;
- added player condition editing;
- added shortlist generation (both text and CM shortlist formats);
- interface improved (injured players and players on loan are highlighted);
- added "save as" option.

CMExplorer 1.2 is a comprehensive editing tool for Championship Manager 00/01 database and saved games.  
With the help of CMExplorer 1.2 one can accomplish the following tasks:


�	Add, delete, and edit players, including editing player contracts and injuries in saved games.
.	Transfer players even in saved games.
�	Add, delete, and edit staff.
�	Add, delete, and edit officials.
�	Add, delete, and edit clubs, including editing club cash in saved games.
�	Edit nations.
�	Edit national clubs.
�	Add, delete, and edit stadiums.
�	Add, delete, and edit cities.
�	Edit names to resolve name generation problems.
�	Scout the entire database for items with given characteristics with the help of filters.
�	Find players and staff with best ratings with the help of the rating sorting capability.
.	Generate staff shortlists.
�	Convenient browsing of the entire database.


CMExplorer offers the user convenient Windows Explorer-type outlook, which makes it easy to use.

Forward your comments and report bugs to yuri@sturgeon.zzn.com

Frequently Asked Questions

These are a couple of questions that I keep getting from the users:

Q: CMExplorer complains that my saved game is compressed. What do I do?
A: To be able to edit a saved game you have to save it uncompressed. Go to CM and click Game Options. Pick Game Settings and set the position Save Compressed to No. Save you game again. Now it can be edited.

Q: CMExplorer 1.0 does not let me edit players. What do I do?
A: Version 1.0 had Scout Mode turned on by default (I thought people would scout more then edit - my fault). Scout Mode can be toggled in the View menu.

Q: Does CMExplorer work with CM99/00?
A: No, as CM00/01 has a different database structure compared to its older versions.

I would also like to thank those people who helped me out with this project, espesially
Andrei Yakovenko, sha of SoccerGamer, Leppy of CMGamer and all other users who sent me
their comments and reports.

*Championship Manager is a trademark of Sports Interactive Ltd.
*Windows Explorer is a trademark of Microsoft Corporation.